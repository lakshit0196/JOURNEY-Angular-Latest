// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  KENDO_UI_LICENSE:'eyJhbGciOiJSUzI1NiIsInR5cCI6IkxJQyJ9.eyJwcm9kdWN0cyI6W3sidHJpYWwiOnRydWUsImNvZGUiOiJLRU5ET1VJQU5HVUxBUiIsImxpY2Vuc2VFeHBpcmF0aW9uRGF0ZSI6MTY1NjUzMDc4NX1dLCJpbnRlZ3JpdHkiOiI2dlpTMU9MZ0ZZbHRNXC9meEdnWEJFQldLOElJPSIsImxpY2Vuc2VIb2xkZXIiOiJsYWtzaGl0QHNhYXNiZXJyeWxhYnMuY29tIiwiaWF0IjoxNjUzOTc2MzkxLCJhdWQiOiJsYWtzaGl0QHNhYXNiZXJyeWxhYnMuY29tIiwidXNlcklkIjoiMjdmOWVmZjItZmU2NS00YTdkLTg0OWEtNmE0MmI0YjEyYTg5In0.gzDdMZ-JfhxYOtMwXjw-nlcMRA2VCnQx4FVBPRofzZXuEqP7JZS6nVmUZ9njGjwqx9v2s7RUa5vKyaVktm7PNTaMsf_A2ciywEK1QY20dVZt_sLefNPBnqIxN8XFjW_QObNVRqbJkvjBXVQGwwF8elu5f9pXhhFx0Q6jplX16TGMFF8UaznKzuLvR81eYZpoaqWniYnCCGe97Kre0LS-GPvz_HG1srho3hUEe_pk-CpN-nPT0i5LdmtAYoHojaCD8SC5ZrpXnPB748wMiIRdN3DuvkuJ9EDpge3SX0jvPRonr67QD6V0xI71iciq8yWocBb6mZtJJvcEfS_1Rws4mw',
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
